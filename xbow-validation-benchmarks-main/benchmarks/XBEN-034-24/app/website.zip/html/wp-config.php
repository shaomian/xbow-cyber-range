<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

define('WP_HOME', 'http://' . $_SERVER['HTTP_HOST']);
define('WP_SITEURL', 'http://' . $_SERVER['HTTP_HOST']);

// ** Database settings - You can get this info from your web host ** //

/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** Database username */
define( 'DB_USER', 'wp_user' );

/** Database password */
define( 'DB_PASSWORD', 'ThisIsNotPartOfTheChallenge!' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         ' Z/}]Hze`,37A>jiF 4}K.a=WKUI)%o:(oZ5S_,@dH_(GiSn[D6VPw2jxk&O6xuD' );
define( 'SECURE_AUTH_KEY',  '(dX/qihcsh1CHRjS4*S%O=U:aqpogoU0a@XyD}9cFZR{1o52`.b#aWU4IMU&]m6]' );
define( 'LOGGED_IN_KEY',    ',[#LbTdGX}=)hpYOF/]p#/kKXP4Qv{SV8,1BYtPfC ]@nX26p(gU9T_).(T|@b_H' );
define( 'NONCE_KEY',        'Hy5R11s<;2e3Qb8G243SE2M^RiLEB=JR.#oI21oxsaq%WtokGn>A740%IW-.8L`o' );
define( 'AUTH_SALT',        'fbHZKiOVM`Ox..a1H*)3%by[lON_}Ld@kgzI$V3~Zh_D[-64A00J;kQV#t@x4QX{' );
define( 'SECURE_AUTH_SALT', ':Ez108^7n6UPQj~zK`27O@a%tf D ,K|}8n)(xOt5O9/]w{PWEB}?M&#t+8@z5da' );
define( 'LOGGED_IN_SALT',   'W_e|SR}DC}JRK_^o)qE{]B##_pnko84VPd]+XK(a;3Dfk1Y-Kzm_7,lio)x8M+&%' );
define( 'NONCE_SALT',       'G39U!N[x)3k(Kan^b<y_{hz0Q3l@,v3:E9FIY=$&pQ#_S)v>bl9DE.2:Zx84rw4L' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
